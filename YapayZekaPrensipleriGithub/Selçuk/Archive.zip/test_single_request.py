import pandas as pd
import requests
import json
import os

# 1. Ayarlar
API_KEY = "AIzaSyCF60H1StSsV8rPAYqoz31hhNKTSRkx7_w"
MODEL = "gemini-flash-latest" # Sende çalışan isim buydu
FILE_PATH = "data/processed/regex_results.xlsx"

def single_request_test(target_id):
    # Excel'den ilgili satırı bul
    if not os.path.exists(FILE_PATH):
        print(f"Hata: {FILE_PATH} dosyası bulunamadı!")
        return

    df = pd.read_excel(FILE_PATH)
    row = df[df['id'] == target_id]

    if row.empty:
        print(f"ID {target_id} bulunamadı!")
        return

    body_text = row.iloc[0]['body']
    print(f"\n--- Analiz Edilen Mesaj (ID: {target_id}) ---")
    print(f"Mesaj: {body_text[:100]}...")

    # API İsteği
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{MODEL}:generateContent?key={API_KEY}"
    headers = {'Content-Type': 'application/json'}
    
    categories = [
        "Bağlantı sorunu", "Donanım talebi", "Erişim hatası", "Erişim talebi",
        "Hata mesajı alıyorum", "Mail grubu ekleme", "Rapor talebi", "Sistem hatası",
        "Sunucuya ulaşılamıyor", "Uygulama çalışmıyor", "VPN bağlantı problemi",
        "VPN erişim isteği", "Yazılım kurulumu", "Yeni kullanıcı isteği", "Yetki talebi"
    ]
    
    prompt = f"Sadece listeden bir kategori seç: {', '.join(categories)}\n\nMesaj: {body_text}"
    payload = {"contents": [{"parts": [{"text": prompt}]}]}

    print("\nAPI İsteği gönderiliyor...")
    response = requests.post(url, headers=headers, data=json.dumps(payload))
    
    if response.status_code == 200:
        res_json = response.json()
        result = res_json["candidates"][0]["content"]["parts"][0]["text"].strip()
        print(f"\n✅ BAŞARILI!")
        print(f"Modelin Belirlediği Kategori: {result}")
    else:
        print(f"\n❌ HATA OLUŞTU!")
        print(f"Durum Kodu: {response.status_code}")
        print(f"Hata Mesajı: {response.text}")

if __name__ == "__main__":
    single_request_test(2045)