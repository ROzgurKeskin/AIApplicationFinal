import pandas as pd
import re
import json
import os

def load_patterns(file_path):
    """JSON dosyasından desenleri yükler, dosya yoksa varsayılanları oluşturur."""
    if not os.path.exists(file_path):
        default_patterns = {
            "hata_patterns": [
                "\\bsorun(?! yok)\\b", "\\bhata(?!sız)\\b", "çalışmıyor", 
                "ulaşılamıyor", "problem", "yüklenmiyor", "düzelmedi", 
                "bozuk", "yavaşlık", "izin vermiyor", "kopma", "donuyor", 
                "hata mesajı", "yanıt vermiyor"
            ],
            "istek_patterns": [
                "\\btalep\\b", "\\bistek\\b", "ekleme", "kurulum", 
                "ihtiyacım var", "tanımlanması", "yeni kullanıcı", "yetki istiyoruz"
            ]
        }
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(default_patterns, f, ensure_ascii=False, indent=4)
        print(f"-> Yeni desen dosyası oluşturuldu: {file_path}")
    
    with open(file_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    return "|".join(data['hata_patterns']), "|".join(data['istek_patterns'])

def run_advanced_regex_pipeline():
    # 1. Hazırlık
    output_dir = "data/processed"
    os.makedirs(output_dir, exist_ok=True)
    pattern_file = "data/patterns.json"
    
    # 2. Yükleme
    hata_pattern, istek_pattern = load_patterns(pattern_file)
    df = pd.read_excel("data/raw/v1_f_IT_Department_Sorunlar_.xlsx")
    
    print(f"\n--- Regex Analiz Katmanı Başlatıldı ---")

    def classify(text):
        if pd.isna(text): return "BELİRSİZ"
        text = str(text).lower()
        
        # Eşleşen tüm kelimeleri bul (Debug için)
        hata_found = re.findall(hata_pattern, text)
        istek_found = re.findall(istek_pattern, text)
        
        has_hata = len(hata_found) > 0
        has_istek = len(istek_found) > 0
        
        # Mantık Denetimi
        if has_hata and not has_istek:
            return "HATA"
        elif has_istek and not has_hata:
            return "İSTEK"
        elif has_hata and has_istek:
            # ÖNEMLİ: Neden BELİRSİZ olduğunu terminalde görelim
            # Örn: 'yanıt vermiyor' (hata) ve 'bilgi verirseniz' (içindeki 'ver' istekle karışıyorsa)
            print(f"[ÇAKIŞMA] Hata: {hata_found} | İstek: {istek_found}")
            return "BELİRSİZ"
        else:
            return "BELİRSİZ"

    # 3. Uygulama
    df['label'] = df['body'].apply(classify)
    
    # 4. İstatistik Raporu
    counts = df['label'].value_counts()
    percentages = df['label'].value_counts(normalize=True) * 100
    
    print("\n" + "="*45)
    print("   1. AŞAMA: REGEX SINIFLANDIRMA SONUÇLARI")
    print("="*45)
    for label in ['HATA', 'İSTEK', 'BELİRSİZ']:
        c = counts.get(label, 0)
        p = percentages.get(label, 0)
        print(f" {label:<12}: {c:>5} Kayıt  [%{p:>5.2f}]")
    print("="*45)

    # 5. Excel Olarak Kaydet (Kolon yapısını korur)
    output_path = os.path.join(output_dir, "regex_results.xlsx")
    df[['id', 'subject', 'body', 'label']].to_excel(output_path, index=False)
    
    print(f"\n-> Sonuçlar kaydedildi: {output_path}")
    print("-> Sistem 2. Aşama (LLM) için hazır.\n")

if __name__ == "__main__":
    # Gerekirse: pip install openpyxl
    run_advanced_regex_pipeline()